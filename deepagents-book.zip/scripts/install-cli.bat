@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion

rem ============================================================
rem  安装 deepagents CLI 全局命令 (Windows)
rem  双击运行或在 cmd/PowerShell 中执行即可
rem
rem  用法:
rem    install-cli.bat                # 默认命令名 xiaolu
rem    install-cli.bat myapp          # 自定义命令名
rem ============================================================

rem 命令名 (默认 xiaolu)
set "CMD_NAME=%~1"
if "%CMD_NAME%"=="" set "CMD_NAME=xiaolu"

rem 定位项目目录
set "SCRIPT_DIR=%~dp0"
rem 去掉末尾反斜杠
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
for %%I in ("%SCRIPT_DIR%") do set "PROJECT_DIR=%%~dpI"
set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"
set "CLI_PROJECT_DIR=%PROJECT_DIR%\libs\deepagents-cli"

rem 安装目录
set "INSTALL_DIR=%LOCALAPPDATA%\deepagents\bin"

echo.
echo === deepagents CLI 全局安装 (Windows) ===
echo.
echo   项目目录: %CLI_PROJECT_DIR%
echo   安装目录: %INSTALL_DIR%
echo   命令名称: %CMD_NAME%
echo.

rem 检查 uv
where uv >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 uv，请先安装:
    echo   https://docs.astral.sh/uv/getting-started/installation/
    echo.
    echo   PowerShell 一键安装 uv:
    echo   irm https://astral.sh/uv/install.ps1 ^| iex
    echo.
    pause
    exit /b 1
)

rem 创建安装目录
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

rem 创建 .cmd 包装脚本
(
    echo @echo off
    echo rem deepagents CLI 全局启动器 ^(自动生成，勿手动编辑^)
    echo rem 项目路径: %CLI_PROJECT_DIR%
    echo uv run --project "%CLI_PROJECT_DIR%" deepagents %%*
) > "%INSTALL_DIR%\%CMD_NAME%.cmd"

echo [OK] 已创建: %INSTALL_DIR%\%CMD_NAME%.cmd
echo.

rem 检查 PATH 并添加
echo %PATH% | findstr /i /c:"%INSTALL_DIR%" >nul 2>&1
if errorlevel 1 (
    rem 添加到用户 PATH
    for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"
    if "!USER_PATH!"=="" (
        setx Path "%INSTALL_DIR%" >nul 2>&1
    ) else (
        setx Path "%INSTALL_DIR%;!USER_PATH!" >nul 2>&1
    )
    set "PATH=%INSTALL_DIR%;%PATH%"
    echo [OK] 已将 %INSTALL_DIR% 添加到用户 PATH
    echo     新终端窗口自动生效，当前窗口也已更新。
    echo.
)

rem 验证
echo 验证安装:
uv run --project "%CLI_PROJECT_DIR%" deepagents --version
if errorlevel 1 (
    echo [警告] 验证失败，请检查 uv 和项目依赖
) else (
    echo [OK] 验证通过
)

echo.
echo ============================================================
echo  安装成功! 现在可以在任意目录使用:
echo.
echo    %CMD_NAME%                     启动交互模式
echo    %CMD_NAME% -r                  恢复最近会话
echo    %CMD_NAME% -r ^<id^>             恢复指定会话
echo    %CMD_NAME% -m "你好"            单次消息
echo    %CMD_NAME% novel init "标题"    小说模式
echo ============================================================
echo.
pause
